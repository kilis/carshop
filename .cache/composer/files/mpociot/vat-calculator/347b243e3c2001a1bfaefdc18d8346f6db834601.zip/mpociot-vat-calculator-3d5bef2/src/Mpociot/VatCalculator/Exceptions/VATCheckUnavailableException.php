<?php

namespace Mpociot\VatCalculator\Exceptions;

use Exception;

class VATCheckUnavailableException extends Exception
{
}
