<?php

return [
    'vat_number' => ':attribute ist keine gültige USt-Id-Nummer.',
];
