<?php

return [
    'vat_number' => ':attribute is not a valid VAT ID number.',
];
