<?php

return [
    'vat_number' => ':attribute nie jest prawidłowym numerem identyfikacji podatkowej VAT.',
];
