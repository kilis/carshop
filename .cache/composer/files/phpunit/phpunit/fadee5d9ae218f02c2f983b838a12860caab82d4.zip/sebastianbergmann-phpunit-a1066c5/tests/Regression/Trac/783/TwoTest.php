<?php
/**
 * @group bar
 */
class TwoTest extends PHPUnit_Framework_TestCase
{
    public function testSomething()
    {
    }
}
