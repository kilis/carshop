<?php namespace Sukohi\Surpass\Facades;

use Illuminate\Support\Facades\Facade;

class Surpass extends Facade {

  protected static function getFacadeAccessor() {

	return 'surpass';

  }

}